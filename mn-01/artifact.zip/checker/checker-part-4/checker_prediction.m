%!test
%! helper_check_prediction('RGB', 20, 0.01, 500);

%!test
%! helper_check_prediction('HSV', 20, 0.01, 500);
